<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_ExtraFee
 * @copyright   Copyright (c) Mageplaza (https://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\ExtraFee\Block\Sales\Order;

use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template;
use Magento\Sales\Model\Order;
use Magento\Tax\Helper\Data as TaxHelper;
use Mageplaza\ExtraFee\Helper\Data;

/**
 * Class AbstractExtraFee
 * @package Mageplaza\ExtraFee\Block\Sales\Order
 */
abstract class AbstractExtraFee extends Template
{
    /**
     * @var Registry
     */
    protected $registry;

    /**
     * @var PriceCurrencyInterface
     */
    protected $priceCurrency;

    /**
     * @var TaxHelper
     */
    protected $taxHelper;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var Order
     */
    protected $order;

    /**
     * AbstractExtraFee constructor.
     *
     * @param Template\Context $context
     * @param Registry $registry
     * @param PriceCurrencyInterface $priceCurrency
     * @param TaxHelper $taxHelper
     * @param Data $helper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Registry $registry,
        PriceCurrencyInterface $priceCurrency,
        TaxHelper $taxHelper,
        Data $helper,
        array $data = []
    ) {
        $this->registry = $registry;
        $this->priceCurrency = $priceCurrency;
        $this->taxHelper = $taxHelper;
        $this->helper = $helper;

        parent::__construct($context, $data);
    }

    /**
     * @param $area
     *
     * @return array
     */
    public function getExtraFeeInfo($area)
    {
        /** @var Order $order */
        $order = $this->getOrder();
        $order->getBaseCurrency();
        $extraFeeTotals = $this->helper->getExtraFeeTotals($order);
        $result = [];
        foreach ($extraFeeTotals as $fee) {
            if ($fee['display_area'] === $area) {
                $result[] = $fee;
            }
        }

        return $result;
    }

    /**
     * @param $fee
     *
     * @return string
     */
    public function getFeeTitle($fee)
    {
        $result = "<strong>{$this->escapeHtml($fee['rule_label'])}"
                  . ($fee['label'] ? " - {$this->escapeHtml($fee['label'])}" : '') . ' </strong>';
        $order = $this->getOrder();

        $baseRuleFeeAmount =
            $this->priceCurrency->format($fee['base_value'], true, 2, null, $order->getBaseCurrency());
        $baseRuleFeeAmountInclTax =
            $this->priceCurrency->format($fee['base_value_incl_tax'], true, 2, null, $order->getBaseCurrency());
        $ruleFeeAmount =
            $this->priceCurrency->format($fee['value_excl_tax'], true, 2, null, $order->getOrderCurrency());
        $ruleFeeAmountInclTax =
            $this->priceCurrency->format($fee['value_incl_tax'], true, 2, null, $order->getOrderCurrency());
        if ($this->taxHelper->displayShippingPriceIncludingTax()) {
            $excl = "<strong>{$baseRuleFeeAmountInclTax}</strong> [{$ruleFeeAmountInclTax}] ";
        } else {
            $excl = "<strong>{$baseRuleFeeAmount}</strong> "
                    . ($order->isCurrencyDifferent() ? "[{$ruleFeeAmount}] " : '');
        }
        $incl = "<strong>{$baseRuleFeeAmountInclTax}</strong> "
                . ($order->isCurrencyDifferent() ? "[{$ruleFeeAmountInclTax}] " : '');
        $result .= $excl;
        if ($incl !== $excl && $this->taxHelper->displayShippingBothPrices()) {
            $result .= ' (' . $this->escapeHtml(__('Incl. Tax ')) . $incl . ')';
        }

        return $result;
    }

    /**
     * @param $fee
     *
     * @return string
     */
    public function getFrontendTitle($fee)
    {
        return $fee['rule_label'] . ($fee['label'] ? " - {$fee['label']}" : '');
    }

    /**
     * @return array
     */
    public function getFrontendExtraFeeInfo()
    {
        $extraFeeTotals = $this->getExtraFeeInfo('3');
        $result = [];
        foreach ($extraFeeTotals as $fee) {
            $result[$fee['rule_label']][] = $fee;
        }

        return $result;
    }

    /**
     * @return mixed
     */
    protected function getOrder()
    {
        if (!$this->order) {
            $this->order = $this->registry->registry('current_order');
        }

        return $this->order;
    }
}
